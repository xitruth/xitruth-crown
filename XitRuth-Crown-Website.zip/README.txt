XitRuth Crown Website
======================

Open index.html in a browser to view the website.

Brand/contact details included:
WhatsApp: 063 670 6637
Email: xitruthcrown@gmail.com
Instagram: @xitruth_crown
TikTok: @xitruth_crown

The site is responsive and includes:
- Premium XitRuth Crown branding
- Hero section using the supplied brand-board image
- About section
- Why-us section
- Featured wigs/shop section
- WhatsApp ordering buttons
- Contact and social links

To make it a full online shop, replace the sample wig cards with real product photos,
names, prices, stock, and payment/checkout details.
